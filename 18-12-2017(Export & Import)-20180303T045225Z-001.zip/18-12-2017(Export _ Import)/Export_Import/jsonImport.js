var http = require("http");
var obj  = require("./config");

var server = http.createServer(function (req,res) {
    res.write(obj.user+"\n");
    res.write(obj.password+"\n");
    res.write(obj.host+"\n");
    res.write(obj.database+"\n");
    res.write(obj.debug+"\n");
    res.write(obj.connectionLimit+"\n");
    res.end();
});

server.listen(8080);
console.log("server listening the port no.8080");