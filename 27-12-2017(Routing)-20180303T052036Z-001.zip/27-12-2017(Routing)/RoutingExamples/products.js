var express = require("express");
var router = express.Router();
router.get("/",function (req,res) {
    res.send({"products":"Welcome to Products Module !"});
});
module.exports = router;