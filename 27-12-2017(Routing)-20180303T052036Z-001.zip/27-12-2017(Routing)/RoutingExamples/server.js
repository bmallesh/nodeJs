var admin = require("./admin");
var customer = require("./customer");
var products = require("./products");
var express = require("express");
var app = express();
app.use(express.static(__dirname+"/../RoutingExamples"));


app.use("/admin",admin);
app.use("/customer",customer);
app.use("/products",products);
app.get("/",function (req,res) {
    res.send({"main":"Welcome to Main Module !"});
});

var bodyparser = require("body-parser");
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));
var login = require("./login");
app.use("/login",login);

app.listen(8080);
console.log("Server Listening the port no.8080");
/*
    http://localhost:8080/
    http://localhost:8080/admin
    http://localhost:8080/customer
    http://localhost:8080/products

    http://localhost:8080/login
    http://localhost:8080/login/login?uname=admin&upwd=admin
 */





