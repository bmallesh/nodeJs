var mongodb = require("mongodb");
var express = require("express");
var bodyparser = require("body-parser");
var app = express();
app.use(express.static(__dirname+"/../NodeJSExamples"));
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:false}));
app.get("/",function (req,res) {
    res.redirect("/register.html");
});
var mongoClient = mongodb.MongoClient;
app.post("/register",function (req,res) {
        var obj = {"uname": req.body.uname,
                   "uaddress":req.body.uaddress,
                   "uphone":req.body.uphone}

        mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
            db.collection("products").insertOne(obj,function (err,result) {
                res.send("record inserted successfully !");
            });
        });
});

app.listen(8080);
console.log("server listening the port no.8080");