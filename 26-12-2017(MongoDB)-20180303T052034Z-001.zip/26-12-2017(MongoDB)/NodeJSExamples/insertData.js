/*
//insert single record
//import the module
var mongodb = require("mongodb");
//create the client
var mongoClient = mongodb.MongoClient;
//connect to database
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    if(err){
        console.log(err);
        throw err;
    }else{
        //find the collection
        var obj = {"p_id":111,"p_name":"p_one","p_cost":10000};
        db.collection("products").insertOne(obj,function (err,res) {
            if(err){
                console.log(err);
                throw err;
            }else{
                console.log("Single Record Inserted Successfully !");
            }
        });
    }
});*/



//insert many records
var mongodb = require("mongodb");
var mongoClient = mongodb.MongoClient;

var array = [
    {"p_id":222,"p_name":"p_two","p_cost":20000},
    {"p_id":333,"p_name":"p_three","p_cost":30000},
    {"p_id":444,"p_name":"p_four","p_cost":40000},
    {"p_id":555,"p_name":"p_five","p_cost":50000}
];


mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
   db.collection("products").insertMany(array,function (err,res) {
        console.log("Records Inserted Successfully !");
   });
});










