//create the db
//import mongodb
var mongodb = require("mongodb");

//create the client
var mongoClient = mongodb.MongoClient;

//connect to server
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    if(err){
        console.log(err);
        throw err;
    } else{
        console.log("DataBase Created Successfully !");
    }
});