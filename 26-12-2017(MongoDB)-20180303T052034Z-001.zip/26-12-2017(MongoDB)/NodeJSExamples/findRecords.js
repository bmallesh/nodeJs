/*
var mongodb = require("mongodb");
var mongoClient = mongodb.MongoClient;
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    db.collection("products").findOne({},function (err,records,fields) {
        console.log(records);
    });
});*/




var mongodb = require("mongodb");
var mongoClient = mongodb.MongoClient;
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    db.collection("products").find().toArray(function (err,array) {
       console.log(array);
    });
});

