//create collection
//import the module
var mongodb = require("mongodb");
//create the client
var mongoClient = mongodb.MongoClient;
//client should connect to mydb
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    if(err){
        console.log(err);
        throw err;
    }else{
        db.createCollection("products",function (err,res) {
           if(err){
               console.log(err);
               throw err;
           }else{
               console.log("collection created successfully !");
           }
        });
    }
});