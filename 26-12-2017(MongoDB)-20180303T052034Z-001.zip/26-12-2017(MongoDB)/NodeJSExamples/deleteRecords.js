/*
var mongodb = require("mongodb");
var mongoClient = mongodb.MongoClient;
var obj = {"p_id":111,"p_name":"p_one","p_cost":10000};
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
   db.collection("products").deleteOne(obj,function (err,res) {
      console.log("Single Record Deleted Successfully");
   });
});*/

var mongodb = require("mongodb");
var mongoClient = mongodb.MongoClient;
var obj = {"p_id":111,"p_name":"p_one","p_cost":10000};
mongoClient.connect("mongodb://localhost:27017/mydb",function (err,db) {
    db.collection("products").deleteMany(function (err,res) {
        console.log("All Records Deleted Successfully");
    });
});
