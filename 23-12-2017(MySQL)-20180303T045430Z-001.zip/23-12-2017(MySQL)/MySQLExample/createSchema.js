var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("create schema nodedb",function (err,result) {
    if(err){
        console.log(err);
        return;
    }
    console.log("DataBase Created Successfully !");
});