var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("update products set cost = 200000 where name='tv'",
        function (err,result) {
    if(err){
        console.log(err);
    }
    else{
        connection.query("select * from products",function (err,recordsArray,fields) {
            if(err){
                console.log(err);
                return;
            } else{
                console.log(recordsArray);
            }
        });
    }
});