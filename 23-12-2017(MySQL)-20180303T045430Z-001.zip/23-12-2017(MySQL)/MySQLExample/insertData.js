var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("insert into products values('tv',10000)",function (err,result) {
    if(err){
        console.log(err);
        return;
    }else{
        console.log("Record Inserted Successfully !");
    }
});