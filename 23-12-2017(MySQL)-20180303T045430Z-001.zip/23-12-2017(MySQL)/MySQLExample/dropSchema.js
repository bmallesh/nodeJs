var db = require("./db-config");
var connection = db.getConnection();
connection.connect();
connection.query("drop schema nodedb",function (err,result) {
    if(err){
        console.log("Error");
        return;
    }else{
        console.log("Schema Dropped !");
    }
});