//import express
//develop the web services
var express = require("express");

//import body-parser
//to set the MIME Type
var bodyparser = require("body-parser");

//import db utility functions
var db = require("./db-config");

//import jwt module utility functions
var jwt = require("./jwt");

//create the Rest Object
//used to create the Rest API
var app = express();

//set the JSON As MIME Type
app.use(bodyparser.json());

//secuirity while reading the post parameters
app.use(bodyparser.urlencoded({extended:false}));

//deploy the application to server
app.use(express.static(__dirname+"/../JWTSimpleExample"));

//launch the login.html as default page
app.get("/",function (req,res) {
    res.redirect("/login.html");
});


//create the post request
app.post("/login",function (req,res) {
    //reading the post parameters
    var uname = req.body.uname;
    var upwd = req.body.upwd;

    //get the pool
    var pool = db.getPool();

    //get the connection object from pool
    pool.getConnection(function (err,connection) {
        //comparision of client details with database
        connection.query("select * from login_details where uname='"+uname+"' AND upwd='"+upwd+"'",function (err,recordsArray,fields) {
            if(recordsArray.length>0){

                //generate the token
                var token = jwt.getToken({'uname':uname,'upwd':upwd},
                    'hr@nareshit.in');

                //send the response to client
                res.send({'login':'success','token':token});
            }else{
                //send the negative response to client
                res.send({'login':'fail'});
            }
        });
    });
});

//assign the port no
app.listen(8080);
console.log("Server Listening the port no.8080");