module.exports = {
    "host":"localhost",
    "user":"root",
    "password":"root",
    "database":"mini_project",
    "token":"",
    'secretKey':'hr@nareshit.in'
};