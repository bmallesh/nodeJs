/*
var express = require("express");
var app = express();
app.get("/login",function (req,res) {
   var uname = req.query.uname;
   var upwd  = req.query.upwd;
   if(uname == "admin" && upwd=="admin"){
        res.send({"login":"success"});
   }else{
       res.send({"login":"fail"});
   }
});
app.listen(8080);
console.log("server listening the port no.8080");*/


var express = require("express");
var app = express();
app.get("/login/:uname/:upwd",function (req,res) {
    var uname = req.params.uname;
    var upwd = req.params.upwd;
    if(uname=="admin" && upwd=="admin"){
        res.send({"login":"success"});
    }else{
        res.send({"login":"fail"});
    }
});
app.listen(8080);
console.log("server listening the port no.8080");

// http://localhost:8080/login/admin/admin












