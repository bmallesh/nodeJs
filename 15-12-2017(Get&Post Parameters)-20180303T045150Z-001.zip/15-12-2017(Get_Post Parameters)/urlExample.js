var url = require("url");
var http = require("http");
var server = http.createServer(function (request,response) {
       response.writeHead(200,{'Content-Type':'text/html'});
       var q_string = url.parse(request.url,true);
       var uname = q_string.query.uname;
       var upwd = q_string.query.upwd;

       if(uname == "admin" && upwd=="admin"){
           response.write("Login Success !");
       }else{
           response.write("Login Fail !");
       }
       response.end();
});
server.listen(8080);
console.log("server listening the port no.8080");