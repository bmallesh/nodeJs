var http = require("http");


var httpServer = http.createServer(my_fun);

function my_fun(request,response) {
    response.writeHead(200,{'Content-Type':'text/html'});
    response.end("<h1>Welcome to First Http Server</h1>");
}

httpServer.listen(8080);
console.log("Server Listening the port no.8080")