var http = require("http");
var fs = require("fs");
var server = http.createServer(function (req,res) {
    fs.writeFile("sample.txt","Welcome...!",function (err) {
        if(err){
            console.log("Error !");
        }else{
            res.end("Data Write Successfully !");
        }
    });
});
server.listen(8080);
console.log("Server Listening the Port No.8080");