var fs = require("fs");
var http = require("http");

var server = http.createServer(function (req,res) {
    /*fs.readFile(__dirname+"/emp.json",function (err,data) {
        if(err){
            console.log(err);
        }else{
            res.end(data.toString());
        }
    });*/
    var result = fs.readFileSync(__dirname+"/emp.json");
    res.end(result.toString());
});

server.listen(8080);
console.log("server listening the port no.8080");
