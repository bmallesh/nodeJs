var http = require("http");
var server = http.createServer(function (req,res) {
    var uname = req.query.uname;
    var upwd  = req.query.upwd;
    var pDetails = {
        name:"TV",
        price:10000
    };
    if(uname == "admin" && upwd == "admin"){
        res.render("views/productDetails",pDetails);
    }else{
        res.end("Failed !");
    }
});
server.listen(8080);
console.log("Server Listening the port no.8080");
