var express = require("express");

var app = express();

app.get("/first_application",function(req,res){
	res.send({"message":"welcome to GET request !"});
});

app.post("/first_application",function(req,res){
	res.send({"message":"welcome to POST request"});
});

app.delete("/first_application",function(req,res){
	res.send({"message":"welcome to Delete request"});
});

app.head("/first_application",function(req,res){
	res.send({"message":"welcome to HEAD request"});
});

app.put("/first_application",function(req,res){
	res.send({"message":"welcome to PUT request"});
});

app.trace("/first_application",function(req,res){
	res.send({"message":"welcome to trace request"});
});

app.options("/first_application",function(req,res){
	res.send({"message":"welcome to OPTIONS request"});
});

app.listen(8080);
console.log("Server Listening the Port No.8080");