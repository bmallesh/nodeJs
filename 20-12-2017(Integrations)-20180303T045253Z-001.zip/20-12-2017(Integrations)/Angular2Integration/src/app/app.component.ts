import {Component} from "@angular/core";
import {MyService} from "./my.service";

@Component({
  selector:"app-root",
  templateUrl:"./app.component.html"
})
export class AppComponent{
  data:any;
  constructor(private __myService:MyService){

  }

  login(arg1,arg2){
    this.__myService.getData({"uname":arg1,"upwd":arg2})
        .subscribe(res=>console.log(res),err=>console.log(err));
  }
}

