//import modules
var express = require("express");
var bodyparser = require("body-parser");

//create Rest Object
var app = express();

//Enable the CORS
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//json as MIME Type
app.use(bodyparser.json());

//secuirity while reading post parameters
app.use(bodyparser.urlencoded({extended:false}));

//create post request
app.post("/login",function (req,res) {
    //read the post parameters
    var uname = req.body.uname;
    var upwd  = req.body.upwd;

    if(uname == "admin" && upwd == "admin"){
        res.send({"login":"success"});
    }else{
        res.send({"login":"fail"});
    }
});

app.listen(8080);
console.log("Server Listening the Port No.8080");